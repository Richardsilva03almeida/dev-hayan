from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,"siteapp/home.html")


def exen(request):
    return render(request,"siteapp/exen.html")
